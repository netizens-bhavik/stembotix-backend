const userData = {
  firstName: "Admin",
  lastName: "Manual",
  email: "admin@yopmail.com",
  password: "admin@123",
  date_of_birth: "07-11-2000",
  isEmailVerified: true,
  role: "admin",
};
export default userData;
