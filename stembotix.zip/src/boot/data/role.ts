const rolesData = [
  { roleName: "admin" },
  { roleName: "student" },
  { roleName: "trainer" },
  { roleName: "company" },
];

export default rolesData;
