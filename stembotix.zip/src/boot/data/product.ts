import { API_BASE } from "@/config"


const productData={
    title :"Product",
    price:5454,
    category:"Uncategorized",
    sku:"vnfdj",
    thumbnail:`${API_BASE}/media/thumbnail/thumbnail_1.jpg`,
    status:"Published",
    description:"Product"
}
export default productData