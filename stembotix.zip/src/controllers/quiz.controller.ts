import { NextFunction, Request, Response } from 'express';
import { Quiz } from '@/interfaces/quiz.interface';
import QuizService from '@/services/quiz.service';

class QuizController{
    public quizService = new QuizService();


    public createQuiz = async(req:Request,res:Response,next:NextFunction)=>{
        try{
            const quizData = req.body;
            const response = await this.quizService.createQuiz(quizData);
            res.status(200).send(response)
        }catch(err){
            next(err)
        }
    }
}export default QuizController