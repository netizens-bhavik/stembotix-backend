module.exports = (sequelize, Sequelize) => {
  const QuizAns = sequelize.define(
    'QuizAns',
    {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true,
      },
      option_first: {
        type: Sequelize.STRING,
      },
      option_sec: {
        type: Sequelize.STRING,
      },
      option_third: {
        type: Sequelize.STRING,
      },
      option_fourth: {
        type: Sequelize.STRING,
      },
    },
    {
      paranoid: true,
    }
  );
  QuizAns.associate = (models) => {
    QuizAns.belongsTo(models.QuizQue, {
      foreignkey: 'question_id',
      targetkey: 'id',
    });
    QuizAns.hasMany(models.QuizQueAns);
  };
  return QuizAns;
};
