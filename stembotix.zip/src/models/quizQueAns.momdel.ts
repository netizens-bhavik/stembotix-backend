module.exports = (sequelize, Sequelize) => {
  const QuizQueAns = sequelize.define(
    'QuizQueAns',
    {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true,
      },
    },
    {
      paranoid: true,
    }
  );
  QuizQueAns.associate = (models) => {
    QuizQueAns.belongsTo(models.QuizAns, {
      foreignkey: 'answer_id',
      targetkey: 'id',
    });
    QuizQueAns.belongsTo(models.QuizQue, {
      foreignkey: 'question_id',
      targetkey: 'id',
    });
  };
  return QuizQueAns;
};
