import { Router } from 'express';
import validationMiddleware from '@middlewares/validation.middleware';
import { Routes } from '@interfaces/routes.interface';
import passport from 'passport';
import passportConfig from '@/config/passportConfig';
import QuizController from '@/controllers/quiz.controller';
import { QuizDto } from '@/dtos/quiz.dto';


class QuizRoute implements Routes{
public path = '/quiz';
  public router = Router();
  public quizController = new QuizController();
  public passport = passportConfig(passport);

  constructor(){
    this.initializeRoutes();
  }

  private initializeRoutes() {

    this.router.post(
        `${this.path}`,
          passport.authenticate('jwt', { session: false }),
          validationMiddleware(QuizDto, 'body'),
        this.quizController.createQuiz
      );
  }
}

export default QuizRoute