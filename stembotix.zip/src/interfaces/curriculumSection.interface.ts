export interface CurriculumSection {
  id: string;
  title: string;
  objective: string;
  course_id: string;
}
