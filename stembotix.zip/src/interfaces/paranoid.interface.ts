export default interface Paranoid {
  createdAt: string;
  updatedAt: string;
  deletedAt: string | null;
}
