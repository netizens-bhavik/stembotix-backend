export interface Role {
  id: string;
  roleName: string;
}
