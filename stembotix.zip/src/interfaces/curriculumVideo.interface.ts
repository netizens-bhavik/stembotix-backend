export interface CurriCulumVideo {
  id: string;
  title: string;
  video_url: string;
}
