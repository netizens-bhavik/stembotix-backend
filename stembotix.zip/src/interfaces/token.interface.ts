export interface Token {
  user_id: string;
  auth_token: string;
  refresh_token: string;
}
