import {Router} from 'express'
export interface Quiz {
  title: string;
  curriculum_id:string
}
