export interface RefreshToken {
  id: number;
  token: string;
  expiry_date: string;
  userId: string;
}
