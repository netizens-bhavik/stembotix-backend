import DB from "@databases"
import { Quiz } from "@/interfaces/quiz.interface"
import { API_BASE } from "@/config"
import { QuizDto } from "@/dtos/quiz.dto"


class QuizService{
    public quiz = DB.Quiz
    public quizQue =DB.QuizQue
    public quizAns =DB.QuizAns
    public quizQueAns =DB.QuizQueAns

    public async createQuiz(quizData:QuizDto):Promise<Quiz>{
        const newQuiz = await this.quiz.create(quizData)
        return newQuiz
    }
    
}
export default QuizService